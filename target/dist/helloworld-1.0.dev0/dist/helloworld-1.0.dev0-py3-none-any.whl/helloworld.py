import sys
def helloworld(out):
	out.write("Hello world of Python\n")